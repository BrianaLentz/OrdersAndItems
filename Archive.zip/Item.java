class Item {
    public String name;
    public double price;

    // public Item(){
    //     this.name = "A random item";
    //     this.price = 5.5;
    // }

    // public void displayStatus(){
    //     System.out.println("Name: " + this.name);
    //     System.out.println("Price: " + this.price);
    // }
    
}